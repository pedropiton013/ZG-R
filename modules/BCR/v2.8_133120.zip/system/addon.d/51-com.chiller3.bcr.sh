#!/sbin/sh
# ADDOND_VERSION=2

. /tmp/backuptool.functions

files="priv-app/com.chiller3.bcr/app-release.apk etc/permissions/privapp-permissions-com.chiller3.bcr.xml"

case "${1}" in
backup|restore)
    for f in ${files}; do
        "${1}_file" "${S}/${f}"
    done
    ;;
esac